#!/usr/bin/env python3
"""
Debug-Skript: Zeige alle DNS-Einträge für eine Domain
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import hostinger_api
from hostinger_api.rest import ApiException

API_KEY = "T8n2HyMTckmghr0lVnx5SgieVtYQMTfic2CaBxap8e99cf02"

def init_api_client():
    configuration = hostinger_api.Configuration(access_token=API_KEY)
    return hostinger_api.ApiClient(configuration)

def show_dns_records(domain):
    api_client = init_api_client()
    api_instance = hostinger_api.DNSZoneApi(api_client)
    
    print(f"\n{'='*80}")
    print(f"DNS-Einträge für: {domain}")
    print(f"{'='*80}\n")
    
    try:
        records = api_instance.get_dns_records_v1(domain)
        
        # Gruppiere nach Typ
        by_type = {}
        for record in records:
            record_dict = record.to_dict()
            record_type = record_dict.get('type', 'UNKNOWN')
            if record_type not in by_type:
                by_type[record_type] = []
            by_type[record_type].append(record_dict)
        
        # Zeige alle Einträge gruppiert nach Typ
        for record_type in sorted(by_type.keys()):
            print(f"\n📋 {record_type} Records:")
            print("-" * 80)
            for record in by_type[record_type]:
                name = record.get('name', 'N/A')
                content = record.get('content', 'N/A')
                ttl = record.get('ttl', 'N/A')
                
                # Zeige auch das volle Record-Dict für Debugging
                print(f"  Name: {name}")
                print(f"  Content: {content}")
                print(f"  TTL: {ttl}")
                
                # Debug: Zeige alle Felder
                print(f"  Raw: {record}")
                print()
        
        print(f"\n✅ Total: {len(records)} DNS-Einträge\n")
        
    except ApiException as e:
        print(f"❌ Fehler: {e}")

if __name__ == "__main__":
    # Domain zum Debuggen
    domain = "gutachterassistent.de"
    
    if len(sys.argv) > 1:
        domain = sys.argv[1]
    
    show_dns_records(domain)
