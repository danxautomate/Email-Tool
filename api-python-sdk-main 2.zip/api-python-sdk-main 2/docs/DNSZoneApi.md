# hostinger_api.DNSZoneApi

All URIs are relative to *https://developers.hostinger.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**delete_dns_records_v1**](DNSZoneApi.md#delete_dns_records_v1) | **DELETE** /api/dns/v1/zones/{domain} | Delete DNS records
[**get_dns_records_v1**](DNSZoneApi.md#get_dns_records_v1) | **GET** /api/dns/v1/zones/{domain} | Get DNS records
[**reset_dns_records_v1**](DNSZoneApi.md#reset_dns_records_v1) | **POST** /api/dns/v1/zones/{domain}/reset | Reset DNS records
[**update_dns_records_v1**](DNSZoneApi.md#update_dns_records_v1) | **PUT** /api/dns/v1/zones/{domain} | Update DNS records
[**validate_dns_records_v1**](DNSZoneApi.md#validate_dns_records_v1) | **POST** /api/dns/v1/zones/{domain}/validate | Validate DNS records


# **delete_dns_records_v1**
> CommonSuccessEmptyResource delete_dns_records_v1(domain, dnsv1_zone_destroy_request)

Delete DNS records

Delete DNS records for the selected domain.

To filter which records to delete, add the `name` of the record and `type` to the filter. 
Multiple filters can be provided with single request.

If you have multiple records with the same name and type, and you want to delete only part of them,
refer to the `Update zone records` endpoint.

Use this endpoint to remove specific DNS records from domains.

### Example

* Bearer Authentication (apiToken):

```python
import hostinger_api
from hostinger_api.models.common_success_empty_resource import CommonSuccessEmptyResource
from hostinger_api.models.dnsv1_zone_destroy_request import DNSV1ZoneDestroyRequest
from hostinger_api.rest import ApiException
from pprint import pprint


# Configure Bearer authorization: apiToken
configuration = hostinger_api.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with hostinger_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = hostinger_api.DNSZoneApi(api_client)
    domain = 'mydomain.tld' # str | Domain name
    dnsv1_zone_destroy_request = hostinger_api.DNSV1ZoneDestroyRequest() # DNSV1ZoneDestroyRequest | 

    try:
        # Delete DNS records
        api_response = api_instance.delete_dns_records_v1(domain, dnsv1_zone_destroy_request)
        print("The response of DNSZoneApi->delete_dns_records_v1:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DNSZoneApi->delete_dns_records_v1: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **domain** | **str**| Domain name | 
 **dnsv1_zone_destroy_request** | [**DNSV1ZoneDestroyRequest**](DNSV1ZoneDestroyRequest.md)|  | 

### Return type

[**CommonSuccessEmptyResource**](CommonSuccessEmptyResource.md)

### Authorization

[apiToken](../README.md#apiToken)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Success response |  -  |
**422** | Validation error response |  -  |
**401** | Unauthenticated response |  -  |
**500** | Error response |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_dns_records_v1**
> List[DNSV1ZoneRecordResource] get_dns_records_v1(domain)

Get DNS records

Retrieve DNS zone records for a specific domain.

Use this endpoint to view current DNS configuration for domain management.

### Example

* Bearer Authentication (apiToken):

```python
import hostinger_api
from hostinger_api.models.dnsv1_zone_record_resource import DNSV1ZoneRecordResource
from hostinger_api.rest import ApiException
from pprint import pprint


# Configure Bearer authorization: apiToken
configuration = hostinger_api.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with hostinger_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = hostinger_api.DNSZoneApi(api_client)
    domain = 'mydomain.tld' # str | Domain name

    try:
        # Get DNS records
        api_response = api_instance.get_dns_records_v1(domain)
        print("The response of DNSZoneApi->get_dns_records_v1:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DNSZoneApi->get_dns_records_v1: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **domain** | **str**| Domain name | 

### Return type

[**List[DNSV1ZoneRecordResource]**](DNSV1ZoneRecordResource.md)

### Authorization

[apiToken](../README.md#apiToken)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Success response |  -  |
**401** | Unauthenticated response |  -  |
**500** | Error response |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **reset_dns_records_v1**
> CommonSuccessEmptyResource reset_dns_records_v1(domain, dnsv1_zone_reset_request)

Reset DNS records

Reset DNS zone to the default records.

Use this endpoint to restore domain DNS to original configuration.

### Example

* Bearer Authentication (apiToken):

```python
import hostinger_api
from hostinger_api.models.common_success_empty_resource import CommonSuccessEmptyResource
from hostinger_api.models.dnsv1_zone_reset_request import DNSV1ZoneResetRequest
from hostinger_api.rest import ApiException
from pprint import pprint


# Configure Bearer authorization: apiToken
configuration = hostinger_api.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with hostinger_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = hostinger_api.DNSZoneApi(api_client)
    domain = 'mydomain.tld' # str | Domain name
    dnsv1_zone_reset_request = hostinger_api.DNSV1ZoneResetRequest() # DNSV1ZoneResetRequest | 

    try:
        # Reset DNS records
        api_response = api_instance.reset_dns_records_v1(domain, dnsv1_zone_reset_request)
        print("The response of DNSZoneApi->reset_dns_records_v1:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DNSZoneApi->reset_dns_records_v1: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **domain** | **str**| Domain name | 
 **dnsv1_zone_reset_request** | [**DNSV1ZoneResetRequest**](DNSV1ZoneResetRequest.md)|  | 

### Return type

[**CommonSuccessEmptyResource**](CommonSuccessEmptyResource.md)

### Authorization

[apiToken](../README.md#apiToken)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Success response |  -  |
**422** | Validation error response |  -  |
**401** | Unauthenticated response |  -  |
**500** | Error response |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_dns_records_v1**
> CommonSuccessEmptyResource update_dns_records_v1(domain, dnsv1_zone_update_request)

Update DNS records

Update DNS records for the selected domain.

Using `overwrite = true` will replace existing records with the provided ones. 
Otherwise existing records will be updated and new records will be added.

Use this endpoint to modify domain DNS configuration.

### Example

* Bearer Authentication (apiToken):

```python
import hostinger_api
from hostinger_api.models.common_success_empty_resource import CommonSuccessEmptyResource
from hostinger_api.models.dnsv1_zone_update_request import DNSV1ZoneUpdateRequest
from hostinger_api.rest import ApiException
from pprint import pprint


# Configure Bearer authorization: apiToken
configuration = hostinger_api.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with hostinger_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = hostinger_api.DNSZoneApi(api_client)
    domain = 'mydomain.tld' # str | Domain name
    dnsv1_zone_update_request = hostinger_api.DNSV1ZoneUpdateRequest() # DNSV1ZoneUpdateRequest | 

    try:
        # Update DNS records
        api_response = api_instance.update_dns_records_v1(domain, dnsv1_zone_update_request)
        print("The response of DNSZoneApi->update_dns_records_v1:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DNSZoneApi->update_dns_records_v1: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **domain** | **str**| Domain name | 
 **dnsv1_zone_update_request** | [**DNSV1ZoneUpdateRequest**](DNSV1ZoneUpdateRequest.md)|  | 

### Return type

[**CommonSuccessEmptyResource**](CommonSuccessEmptyResource.md)

### Authorization

[apiToken](../README.md#apiToken)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Success response |  -  |
**422** | Validation error response |  -  |
**401** | Unauthenticated response |  -  |
**500** | Error response |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **validate_dns_records_v1**
> CommonSuccessEmptyResource validate_dns_records_v1(domain, dnsv1_zone_update_request)

Validate DNS records

Validate DNS records prior to update for the selected domain.

If the validation is successful, the response will contain `200 Success` code.
If there is validation error, the response will fail with `422 Validation error` code.

Use this endpoint to verify DNS record validity before applying changes.

### Example

* Bearer Authentication (apiToken):

```python
import hostinger_api
from hostinger_api.models.common_success_empty_resource import CommonSuccessEmptyResource
from hostinger_api.models.dnsv1_zone_update_request import DNSV1ZoneUpdateRequest
from hostinger_api.rest import ApiException
from pprint import pprint


# Configure Bearer authorization: apiToken
configuration = hostinger_api.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with hostinger_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = hostinger_api.DNSZoneApi(api_client)
    domain = 'mydomain.tld' # str | Domain name
    dnsv1_zone_update_request = hostinger_api.DNSV1ZoneUpdateRequest() # DNSV1ZoneUpdateRequest | 

    try:
        # Validate DNS records
        api_response = api_instance.validate_dns_records_v1(domain, dnsv1_zone_update_request)
        print("The response of DNSZoneApi->validate_dns_records_v1:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DNSZoneApi->validate_dns_records_v1: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **domain** | **str**| Domain name | 
 **dnsv1_zone_update_request** | [**DNSV1ZoneUpdateRequest**](DNSV1ZoneUpdateRequest.md)|  | 

### Return type

[**CommonSuccessEmptyResource**](CommonSuccessEmptyResource.md)

### Authorization

[apiToken](../README.md#apiToken)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Success response |  -  |
**422** | Validation error response |  -  |
**401** | Unauthenticated response |  -  |
**500** | Error response |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

