#!/usr/bin/env python3
"""
AWS SES Verification Status Checker
Prüft ob alle Domains und E-Mails in AWS SES verifiziert sind
"""

import boto3
from botocore.exceptions import ClientError

def check_ses_status():
    """Prüfe den Verifizierungsstatus aller Domains in AWS SES"""
    
    print("\n" + "="*80)
    print("🔍 AWS SES Verifizierungsstatus")
    print("="*80 + "\n")
    
    # AWS SES Client
    ses = boto3.client('ses', region_name='us-east-1')
    
    try:
        # Hole alle verifizierten Identities
        response = ses.list_identities(IdentityType='Domain')
        domains = response['Identities']
        
        print(f"📊 {len(domains)} Domains in AWS SES gefunden\n")
        
        verified_count = 0
        pending_count = 0
        failed_count = 0
        
        for domain in sorted(domains):
            try:
                # Hole Verification Attributes
                attrs = ses.get_identity_verification_attributes(Identities=[domain])
                status = attrs['VerificationAttributes'].get(domain, {}).get('VerificationStatus', 'Unknown')
                
                # DKIM Attributes
                dkim_attrs = ses.get_identity_dkim_attributes(Identities=[domain])
                dkim_status = dkim_attrs['DkimAttributes'].get(domain, {}).get('DkimVerificationStatus', 'Unknown')
                dkim_enabled = dkim_attrs['DkimAttributes'].get(domain, {}).get('DkimEnabled', False)
                
                # Status Icon
                if status == 'Success' and dkim_status == 'Success':
                    icon = "✅"
                    verified_count += 1
                elif status == 'Pending' or dkim_status == 'Pending':
                    icon = "⏳"
                    pending_count += 1
                else:
                    icon = "❌"
                    failed_count += 1
                
                # Ausgabe
                print(f"{icon} {domain}")
                print(f"   Domain: {status}")
                print(f"   DKIM: {dkim_status} (Enabled: {dkim_enabled})")
                print()
                
            except Exception as e:
                print(f"❌ {domain}: Fehler beim Abrufen - {e}\n")
                failed_count += 1
        
        # Zusammenfassung
        print("="*80)
        print("📊 ZUSAMMENFASSUNG")
        print("="*80)
        print(f"✅ Verifiziert: {verified_count} Domains")
        print(f"⏳ Ausstehend: {pending_count} Domains")
        print(f"❌ Fehlgeschlagen: {failed_count} Domains")
        print(f"📝 Gesamt: {len(domains)} Domains")
        print("="*80 + "\n")
        
        if pending_count > 0:
            print("💡 Hinweis: DNS-Propagierung kann bis zu 48 Stunden dauern.")
            print("   Die meisten Einträge werden aber innerhalb von 1-2 Stunden erkannt.\n")
        
    except ClientError as e:
        print(f"❌ Fehler beim Abrufen der SES-Daten: {e}")

if __name__ == "__main__":
    check_ses_status()
