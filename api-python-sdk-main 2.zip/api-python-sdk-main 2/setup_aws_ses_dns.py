#!/usr/bin/env python3
"""
AWS SES DNS Setup Script für Hostinger
Dieses Skript:
1. Löscht alte SPF, DKIM und DMARC Einträge
2. Fügt neue AWS SES DNS-Einträge hinzu
"""

import sys
import os
import time
import json
from typing import List, Dict

# Füge das Verzeichnis zum Python Path hinzu
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import hostinger_api
from hostinger_api.rest import ApiException

# Konfiguration
API_KEY = "T8n2HyMTckmghr0lVnx5SgieVtYQMTfic2CaBxap8e99cf02"

# AWS SES DNS Konfiguration aus vorheriger Session
AWS_SES_DNS_RECORDS = {
    # MAIL-FROM Domains
    "mail.automatenext.ai": {
        "dkim_tokens": [],  # Wird von mail_from_mx abgedeckt
        "mail_from_mx": "feedback-smtp.us-east-1.amazonses.com",
        "spf": "v=spf1 include:amazonses.com ~all",
        "dmarc": "v=DMARC1; p=quarantine; rua=mailto:emre@automatenext.ai"
    },
    "mail.gutachterassistent.de": {
        "dkim_tokens": [],
        "mail_from_mx": "feedback-smtp.us-east-1.amazonses.com",
        "spf": "v=spf1 include:amazonses.com ~all",
        "dmarc": "v=DMARC1; p=quarantine; rua=mailto:emre@gutachterassistent.de"
    }
}

# Alle Domains die konfiguriert werden sollen
ALL_DOMAINS = [
    "aibyentic.de",
    "aiwithentic.de",
    "beyondentic.de",
    "discoverentic.de",
    "entic-ai.de",
    "entic-chat.de",
    "entic-flow.de",
    "entic-ki.de",
    "entic-labs.de",
    "entic-one.de",
    "entic-pro.de",
    "entic-tech.de",
    "entic-voice.de",
    "enticcloud.de",
    "enticdata.de",
    "enticflow.de",
    "enticlabs.de",
    "enticone.de",
    "enticplus.de",
    "enticpro.de",
    "heyentic.de",
    "joinentic.de",
    "madebyentic.de",
    "meetentic.de",
    "my-entic.de",
    "myentic.de",
    "next-entic.de",
    "nextentic.de",
    "poweredbyentic.de",
    "runonentic.de",
    "entictech.de",
    "enticup.de",
    "enticx.de",
    "getentic.de",
    "go-entic.de",
    "goentic.de",
    "grow-with-entic.de",
    "growwithentic.de",
    "hello-entic.de",
    "helloentic.de",
    "start-entic.de",
    "talk-with-entic.de",
    "teamentic.de",
    "thinkentic.de",
    "thisisentic.de",
    "try-entic.de",
    "tryentic.de",
    "use-entic.de",
    "we-entic.de",
    "workwithentic.de"
]

# DKIM Tokens für alle Domains (von AWS SES abgerufen)
DKIM_TOKENS = {
    "aibyentic.de": ["cec22gbkrcppabnn7ahihf4pjkj3yzry", "4qchchumkbuhof6mjz44t4cvaku2b663", "lxy5u5g5jsgihmdbpwmur4svaplpaasq"],
    "aiwithentic.de": ["lsrcopxllxi45u6i5247hghy2z5n43lc", "ao5ttzur5w7cw4zrgl6fladyk4b2zhlg", "7undq6k67ugjbai4gy3xln35hb4e7gwq"],
    "beyondentic.de": ["csdkjhl4kswlyfahhpjjhxarmvnsktu6", "trmsapwxira3ldkoj5emqe622l76sf4a", "rztkgom7tiskxehn7mzheebjriye7vhw"],
    "discoverentic.de": ["iph4guik3rkgbx4fkkomyrdyhu6igdys", "blobrnoajnwyvzg5ye5oxjlsroqrm2bt", "wonlo77nwsxjbn27qfrtu3hputczrqoi"],
    "entic-ai.de": ["c2edadrezr7t4gl47cbovzqrpe4niv7m", "4srw72ygxxphsees7pdxrt6x75rtqpci", "ajva56qm5ycegag54lngw7g3ter7us7u"],
    "entic-chat.de": ["ykxdfpcieiatd6jgwsbf6qa3xt3ok4iq", "7rpx7cf3i6562v2yotxqiee5egctz4w4", "7xdxskzqnkjop3tvqtaumzkxsjblc3rm"],
    "entic-flow.de": ["r34tjt5oxjqwzwlcafylarq5r3ub5msh", "p7hlcq4faqqlafi2dofoqom6zpvqq4qo", "cesqsrk4epqd52xaged6itpmcp2blhgx"],
    "entic-ki.de": ["bdxpfslz2fwebfzrxqmxvwntguhzuecs", "sukgrldg5bjcgbjjou354t7z4bwaeqhw", "abteuxnfe5hrrg2oqgau5mh5brjkv3ie"],
    "entic-labs.de": ["wvf4oyzyznm4qia7ljucmhyd32yi5iec", "nrl6qwhvw3utxngkbtqf5bge2zf7nltn", "dzdshycxislaj76vlrqf24e3chfrbn7s"],
    "entic-one.de": ["534vukr3yu4idnq5mvk6h7dpe3mqusac", "hhse6uqgmtpehjtsvvu2wwfkqkejarhr", "rpjpftswrpl4zfzdggad4lxpg2uqcqfb"],
    "entic-pro.de": ["co4etnwzi6ks2lozpvda252uujvt5n4c", "he7u2p5ivraxztk7hbi6cfhfnjfci66f", "umyisl4vno6oxnrorqth5oj7ipl4hwmb"],
    "entic-tech.de": ["cqlo3yffvw567nb2tfyrez6qrlocvtxs", "5y4fv6tjxlve4mb7tv7nqyk4spxfbv32", "yrsyxbf5xaxmmqlpq3dzb4fxx56u2gb5"],
    "entic-voice.de": ["doru2mn7dncqumhnyihvvsf6nv3vwwxf", "rdor6jefk3ngeb5oybuvachqv3uswm6u", "fongj7u6yo3ftoeavtmltel3sz24nogg"],
    "enticcloud.de": ["fvl6yl5ydyyxkxmcou7a4kyr5hrb3hhg", "imex3w624ukseypvfjikyjaq7oc5rb62", "2vqywnf2rdvchfwn2ps7wwj553cvi3gb"],
    "enticdata.de": ["c4guxeh3gsgp2waxqufrc3xaf3m3euxb", "sculgy6tgdwpxhoahlqos2doc6p6s2r5", "e6m4ae6tdxak2l6gmp5liq5hta52emxu"],
    "enticflow.de": ["6ay6vnpjespm4nvo4wvu4h6qum5s7mzw", "cpvapjp2k3u6asdvyv62m6vys4hkchpl", "xqfx4z4dfoj35efjli4s2sfxolvlr4v3"],
    "enticlabs.de": ["f2zmwxjb7jz26ncxummc266wlpvxgvbx", "uccx7eaicxy4kdjwwmv4uqtxtmtd25y3", "xcbqq2tg5oql5ofcp7o5elxtlwew6c3g"],
    "enticone.de": ["koig5bqozll5zao2bsm234kcayr7cu6l", "dygukqt7zj47ovesjgk2z2syirfpjmc7", "ulll35onlorkv5ashxww6vgnpgr63si2"],
    "enticplus.de": ["v7gtqlsyeb4tb36ibpxepumnjihokzxc", "im4gu2z46udljkq7ubixn57yeuxctdfy", "dftzfnvgzhrlgkqespibmg6pvyacf5lk"],
    "enticpro.de": ["eq4hg3xmzk2pugudhe7tj2duc2jka53y", "xzskt3fdwu2podj2qcyki2etn6zklqrr", "pcgv5dzrxfk5ifmds2wrhsz3fjjcbbbh"],
    "heyentic.de": ["mioc3p5pfzguykvd3r5gffnvzhlokxzu", "txkqjqbkeaghrdotgfrnk5pygysjlwqa", "z5sp2kkpfkmue26umuih76ftmsvmhjtc"],
    "joinentic.de": ["4qth6yifko3nlnoic7ylrhkkogm6awj7", "2jztpfi4pd6ec4cmpd4nlt42owxkwkdb", "fsy5axx5x74qgqut3wa6zdqhkzvf4xhp"],
    "madebyentic.de": ["cctfnpdnyz2wm6mojrh3yvrdczcneiaa", "kxyyr25rl74d34fcnfljqgkmb5cyu2b5", "vauctjquivagv65utodgklnmsowse4k7"],
    "meetentic.de": ["sai6invacxdz2utwkehq4uy42s3hrvxj", "oymxrptifd3ly5v46rvw2yvpmxb4xs72", "5jdlf4iauamtq2ze2mii4jadpywrsg36"],
    "my-entic.de": ["ww6tqxrdyuwfwesfyrmm5dnpjgh4z564", "z62qthl5sqyozes4efakctp35skcoyz7", "sjqhwwdh3xmggfjrseplocrs4mhyyqqb"],
    "myentic.de": ["ovqs7wcpzdkirja6bz72rxhkoljz3wld", "6clkd35ijek3dnjonl6bzhn4w65osqel", "adgpzeizmj2xsxij3rma6iin6jeafq3r"],
    "next-entic.de": ["yktsekbq4eretus5rnrgbskkmo6itfec", "ws2xvwo4c776iy6hl4jjvwoqr3fb2vgm", "u7vuqr6c3z53rdq4kk747lmvcjaorkl7"],
    "nextentic.de": ["25ebjxkbasotnuewfkkaizbhvxy3634y", "kwyyh5uzsuaikobqjupqugsiihcfypzy", "y4btkjmgkqxtvdqeemjl2ufspdaebt27"],
    "poweredbyentic.de": ["qwhgr5ylke6ebt4qsgdz35likhulhghg", "3jtuc4wacol33gpas6gkw4aemhee3fyj", "zx6nxnvphc7rwkglmiequfhxtso7hztv"],
    "runonentic.de": ["jtp4n5hm6zt7lxsjzsmhmkjny53filzv", "ia5w333rzgszvyfb5w4yj2dj6qj5a46g", "3l6vevl2ahm4slwvuqmyijjmy2gsygmo"],
    "entictech.de": ["pugvotaslwa22rwmezm6aibzdl4bai6r", "kxi74mwrficngi3ry23e5sepn3mkdyfs", "hrk7aoabbj7vbu7omtj64kxkdwceqa3l"],
    "enticup.de": ["wreshfs7bbullxwgm4letcg2io5yt4fp", "5cgdha5xt47onmfcuz32vuzy2u7ybdxy", "nkf6agqnh3ezxkczxod64fw4o7pycg3f"],
    "enticx.de": ["p2t4xjriieib3vonbeofkeicehwsfhsp", "ffds37w57bghe5cuzkaq4bxkkstn6qia", "5lmcih5h6zgpadbib6um3kceap7ldvav"],
    "getentic.de": ["ybwtckvr2nma7qxic672fekgpv5asjlg", "f7jkhutvmafqphmr6igs4a6qqcvkklve", "cbxo2etgjhwtopotg2mfllrto6gb4n7w"],
    "go-entic.de": ["55evoeoksihik2y2ezfp4ec3qxei2kcy", "vkg3g4mok5eawzccwgqfy2cslw5nzfpu", "zdh4nzcmjk3cnya2ge62nw4zs3c2fw4m"],
    "goentic.de": ["jgjdzvm6ic3a2i4pjuoekrv43bar3aqe", "7m425aqjo6cslzg64jkdmsqqv3ny552k", "xu5mijqfnpeoseiobvflomocscbtg6si"],
    "grow-with-entic.de": ["pad5vp7nkheaafmvcch2kosfjfkxb7a2", "yobn5hig3g7up4b4irxh2fhzrbyeobny", "3k6lhsjwvt3eg4uhaunk6c5e45gelis2"],
    "growwithentic.de": ["p6qasrnwyk3zyu55k7yzdxi6jfjsjfyl", "mwphtgrtjs3nrwbsyr5rrfq4bpfj4u26", "iqjgg5u5kpl2xsb5es5dlnksiyflb2ph"],
    "hello-entic.de": ["cwu4jigzt3tr4fzha32dynuuiansglnz", "vtdjzd6422qarxbqqsst22vfktsxius3", "ryodted5j7kp5p2lhhxlezkm3cxhrowa"],
    "helloentic.de": ["tddt4dyccsbmxlhxvmyhvhdmlft3isgi", "qwhrm54o2hpa6q6dkfwlws35svet7rij", "5y4h37qpin2hpydkgjgouyc2x6prmeym"],
    "start-entic.de": ["njjlzacidx44ifq3qwoa3xph2ydxfzpu", "moonph5uq27onez7v6aw4rhzlnysxody", "y4cxgfb7vlqhgea6sqh4yklvhb2te6bl"],
    "talk-with-entic.de": ["6fwpioopnoo7r7kisemhkxzb7xt6xpdx", "7n6n5fswppwdocjdpl4kjtecdnth225h", "e4cno3m5dleyodrblf5etp2uvp72tbhi"],
    "teamentic.de": ["ubwzsu6fjdwqvc7ljgia37l4hylbr2zf", "4ryximdznl3ik6mxswrpo5eqvrkf3hre", "7s2bdh4oqn5dwwj6iibixcz66avvk3ax"],
    "thinkentic.de": ["wtnfsl6o43s5czmhveah3howqg4ors6f", "3rubdwdujcc2frtwbayk7f6zocylorrx", "mtf4jgs4z5gyp2xugnpant6hy3wruuej"],
    "thisisentic.de": ["xre2vylrvkorxttnv7gedpue25hj2eh4", "o7nsssgswcvprp4u5qah75fbdqek7u5q", "gtdkstcssagapynaxoinmx6fdbhqpyqq"],
    "try-entic.de": ["nmoruioe6a7ryuhjxqtodjr3e6rbqred", "vniz3q5rys7mig7zupgsvv2otk2sbgqq", "os6j3rqwek6fsat6a5dcnmjdmmx75fvt"],
    "tryentic.de": ["fbf3ltr4jdyoyjdnivryrwbt4sh6k5qd", "hj4z45hpuxw57zipf4mioylw4uwltlsy", "rrsaoze5vzxv4ek25rdti56yhp2zh2pg"],
    "use-entic.de": ["qn3mqwm7pa5uvovwc7l3h2d7kfhzoxql", "byk4gqulmh33lhfk6hc5etge4uptwgka", "72h5qw46fuso72kom5wyz3geaqe7hfia"],
    "we-entic.de": ["kltj5popbkv7mgiph5l332k4vuucva35", "svzvireikyfocfmkud3k6yogoc7p5djj", "tmfjimf67ghwopmnsdvcuct5hmvnmuo4"],
    "workwithentic.de": ["qgyx5udws5vlx3rcfeknip7rcjzzso7m", "m47utqtpffwyddlstv3iwui3wpx4lj5y", "q3p6rmd3oa4ws7g62sulecl6j6m7eqdt"],
}


def init_api_client():
    """Initialisiere Hostinger API Client"""
    configuration = hostinger_api.Configuration(
        access_token=API_KEY
    )
    return hostinger_api.ApiClient(configuration)


def get_existing_records(api_client, domain: str) -> List:
    """Hole bestehende DNS-Einträge für eine Domain"""
    api_instance = hostinger_api.DNSZoneApi(api_client)
    
    try:
        records = api_instance.get_dns_records_v1(domain)
        return records
    except ApiException as e:
        print(f"❌ Fehler beim Abrufen der DNS-Einträge für {domain}: {e}")
        return []


def delete_old_email_records(api_client, domain: str):
    """Lösche ALLE alten SPF, DKIM, DMARC und Amazon SES MX-Einträge (inkl. Duplikate)"""
    print(f"\n🔍 Prüfe {domain} auf alte E-Mail DNS-Einträge...")
    
    records = get_existing_records(api_client, domain)
    
    if not records:
        print(f"  ℹ️  Keine DNS-Einträge gefunden")
        return
    
    api_instance = hostinger_api.DNSZoneApi(api_client)
    
    # WICHTIG: Lösche jede Art von Eintrag separat, um sicherzustellen dass ALLE gelöscht werden
    deleted_count = 0
    
    # 1. Lösche ALLE SPF TXT-Einträge (@ TXT mit v=spf1 UND mail TXT mit v=spf1)
    spf_records = []
    for record in records:
        record_dict = record.to_dict()
        record_type = record_dict.get('type', '')
        record_name = record_dict.get('name', '')
        
        # Prüfe auf SPF: TXT-Einträge die v=spf1 enthalten
        if record_type == 'TXT':
            # WICHTIG: content ist NICHT direkt im dict, sondern in records[].content!
            records_list = record_dict.get('records', [])
            for rec in records_list:
                content = rec.get('content', '')
                # Entferne Anführungszeichen und prüfe
                content_clean = content.strip('"').strip("'")
                if 'v=spf1' in content_clean.lower():
                    spf_records.append({
                        'name': record_name,
                        'type': record_type,
                        'ttl': record_dict.get('ttl'),
                        'content': content
                    })
                    print(f"  🔍 SPF gefunden: {record_name} = {content} (TTL: {record_dict.get('ttl', 'N/A')})")
                    break  # Nur einmal pro Record hinzufügen
    
    if spf_records:
        print(f"  🗑️  Lösche {len(spf_records)} SPF-Einträge...")
        for spf in spf_records:
            try:
                delete_request = hostinger_api.DNSV1ZoneDestroyRequest(
                    filters=[
                        hostinger_api.DNSV1ZoneDestroyRequestFiltersInner(
                            name=spf['name'],
                            type='TXT'
                        )
                    ]
                )
                api_instance.delete_dns_records_v1(domain, delete_request)
                print(f"     ✅ SPF: {spf['name']} (TTL: {spf.get('ttl', 'N/A')})")
                deleted_count += 1
                time.sleep(0.3)
            except ApiException as e:
                if "not found" not in str(e).lower():
                    print(f"     ⚠️  Fehler: {e}")
    
    # 2. Lösche ALLE DMARC TXT-Einträge
    dmarc_records = []
    for record in records:
        record_dict = record.to_dict()
        record_name = record_dict.get('name', '')
        if record_dict.get('type') == 'TXT' and ('_dmarc' in record_name):
            # Prüfe auch den Content
            records_list = record_dict.get('records', [])
            for rec in records_list:
                content = rec.get('content', '')
                if 'v=DMARC' in content:
                    dmarc_records.append({
                        'name': record_name,
                        'type': 'TXT'
                    })
                    break
    
    if dmarc_records:
        print(f"  🗑️  Lösche {len(dmarc_records)} DMARC-Einträge...")
        for dmarc in dmarc_records:
            try:
                delete_request = hostinger_api.DNSV1ZoneDestroyRequest(
                    filters=[
                        hostinger_api.DNSV1ZoneDestroyRequestFiltersInner(
                            name=dmarc['name'],
                            type='TXT'
                        )
                    ]
                )
                api_instance.delete_dns_records_v1(domain, delete_request)
                print(f"     ✅ DMARC: {dmarc['name']}")
                deleted_count += 1
                time.sleep(0.3)
            except ApiException as e:
                if "not found" not in str(e).lower():
                    print(f"     ⚠️  Fehler: {e}")
    
    # 3. Lösche ALLE DKIM CNAME-Einträge
    dkim_records = []
    for record in records:
        record_dict = record.to_dict()
        if '_domainkey' in record_dict.get('name', ''):
            dkim_records.append({
                'name': record_dict.get('name'),
                'type': record_dict.get('type')
            })
    
    if dkim_records:
        print(f"  🗑️  Lösche {len(dkim_records)} DKIM-Einträge...")
        for dkim in dkim_records:
            try:
                delete_request = hostinger_api.DNSV1ZoneDestroyRequest(
                    filters=[
                        hostinger_api.DNSV1ZoneDestroyRequestFiltersInner(
                            name=dkim['name'],
                            type=dkim['type']
                        )
                    ]
                )
                api_instance.delete_dns_records_v1(domain, delete_request)
                print(f"     ✅ DKIM: {dkim['name']}")
                deleted_count += 1
                time.sleep(0.3)
            except ApiException as e:
                if "not found" not in str(e).lower():
                    print(f"     ⚠️  Fehler: {e}")
    
    # 4. Lösche ALLE Amazon SES MX-Einträge (aber NICHT Hostinger MX!)
    amazon_mx_records = []
    for record in records:
        record_dict = record.to_dict()
        if record_dict.get('type') == 'MX':
            # Prüfe alle records im Array
            records_list = record_dict.get('records', [])
            for rec in records_list:
                content = rec.get('content', '')
                if 'amazonses.com' in content.lower():
                    amazon_mx_records.append({
                        'name': record_dict.get('name'),
                        'type': 'MX',
                        'content': content
                    })
                    break
    
    if amazon_mx_records:
        print(f"  🗑️  Lösche {len(amazon_mx_records)} Amazon SES MX-Einträge...")
        for mx in amazon_mx_records:
            try:
                delete_request = hostinger_api.DNSV1ZoneDestroyRequest(
                    filters=[
                        hostinger_api.DNSV1ZoneDestroyRequestFiltersInner(
                            name=mx['name'],
                            type='MX'
                        )
                    ]
                )
                api_instance.delete_dns_records_v1(domain, delete_request)
                print(f"     ✅ Amazon MX: {mx['name']} → {mx['content']}")
                deleted_count += 1
                time.sleep(0.3)
            except ApiException as e:
                if "not found" not in str(e).lower():
                    print(f"     ⚠️  Fehler: {e}")
    
    if deleted_count > 0:
        print(f"  ✅ {deleted_count} alte E-Mail DNS-Einträge gelöscht")
    else:
        print(f"  ✅ Keine alten E-Mail DNS-Einträge gefunden")


def add_aws_ses_records(api_client, base_domain: str, original_domain: str, dkim_tokens: List[str], mail_from_domain: str = None):
    """Füge AWS SES DNS-Einträge hinzu UND stelle sicher, dass Hostinger MX-Einträge korrekt sind
    
    Args:
        base_domain: Die Basis-Domain wo die DNS-Einträge angelegt werden (z.B. solarcheck365.de)
        original_domain: Die ursprüngliche Domain (kann Subdomain sein, z.B. n8n.solarcheck365.de)
        dkim_tokens: DKIM-Tokens für die Domain
        mail_from_domain: Optional MAIL-FROM Domain
    """
    print(f"\n📝 Füge AWS SES DNS-Einträge für {original_domain} hinzu...")
    
    api_instance = hostinger_api.DNSZoneApi(api_client)
    
    new_records = []
    
    # DKIM CNAME Records (3 Stück) - NUR DKIM!
    for i, token in enumerate(dkim_tokens, 1):
        if base_domain != original_domain:
            subdomain = original_domain.replace(f".{base_domain}", "")
            record_name = f"{token}._domainkey.{subdomain}"
        else:
            record_name = f"{token}._domainkey"
        
        new_records.append({
            "name": record_name,
            "type": "CNAME",
            "content": f"{token}.dkim.amazonses.com",
            "ttl": 60
        })
    
    # SPF TXT Record
    spf_value = "v=spf1 include:amazonses.com ~all"
    if base_domain != original_domain:
        subdomain = original_domain.replace(f".{base_domain}", "")
        spf_name = subdomain
    else:
        spf_name = "@"
    
    new_records.append({
        "name": spf_name,
        "type": "TXT",
        "content": spf_value,
        "ttl": 60
    })
    
    # DMARC TXT Record
    dmarc_email = f"emre@{original_domain}"
    if original_domain.startswith("mail."):
        base = original_domain.replace("mail.", "")
        dmarc_email = f"emre@{base}"
    
    dmarc_value = f"v=DMARC1; p=quarantine; rua=mailto:{dmarc_email}"
    
    if base_domain != original_domain:
        subdomain = original_domain.replace(f".{base_domain}", "")
        dmarc_name = f"_dmarc.{subdomain}"
    else:
        dmarc_name = "_dmarc"
    
    new_records.append({
        "name": dmarc_name,
        "type": "TXT",
        "content": dmarc_value,
        "ttl": 60
    })
    
    # Füge jeden Eintrag einzeln hinzu (zuverlässiger als Batch)
    success_count = 0
    for record in new_records:
        try:
            # Für ALLE TXT-Einträge (SPF, DMARC, Subdomains): overwrite=True
            # Damit werden ALLE alten Einträge ersetzt statt hinzugefügt (auch Duplikate!)
            # Für DKIM CNAME: overwrite=False (hinzufügen)
            should_overwrite = record["type"] == "TXT"
            
            # Erstelle das korrekte Update Request Objekt
            update_request = hostinger_api.DNSV1ZoneUpdateRequest(
                overwrite=should_overwrite,  # Überschreibe nur SPF/DMARC TXT-Einträge
                zone=[
                    hostinger_api.DNSV1ZoneUpdateRequestZoneInner(
                        name=record["name"],
                        type=record["type"],
                        ttl=record["ttl"],
                        records=[
                            hostinger_api.DNSV1ZoneUpdateRequestZoneInnerRecordsInner(
                                content=record["content"]
                            )
                        ]
                    )
                ]
            )
            
            api_instance.update_dns_records_v1(base_domain, update_request)
            print(f"     ✅ {record['type']}: {record['name']}")
            success_count += 1
            time.sleep(0.5)  # Rate limiting
        except ApiException as e:
            if "already exists" in str(e).lower() or "duplicate" in str(e).lower():
                print(f"     ℹ️  {record['type']}: {record['name']} (existiert bereits)")
                success_count += 1
            else:
                print(f"     ❌ {record['type']}: {record['name']} - Fehler: {e}")
    
    print(f"  ✅ {success_count}/{len(new_records)} DNS-Einträge hinzugefügt")
    
    # WICHTIG: Prüfe und füge Hostinger MX-Einträge hinzu falls nötig
    ensure_hostinger_mx_records(api_client, base_domain)


def ensure_hostinger_mx_records(api_client, domain: str):
    """Stelle sicher, dass die korrekten Hostinger MX-Einträge existieren"""
    print(f"\n🔍 Prüfe Hostinger MX-Einträge für {domain}...")
    
    # Hole aktuelle DNS-Einträge
    records = get_existing_records(api_client, domain)
    
    # Finde @ MX-Einträge
    mx_records = []
    for record in records:
        record_dict = record.to_dict()
        if record_dict.get('type') == 'MX' and record_dict.get('name') == '@':
            records_list = record_dict.get('records', [])
            for rec in records_list:
                content = rec.get('content', '')
                mx_records.append({
                    'content': content,
                    'ttl': record_dict.get('ttl')
                })
    
    # Prüfe ob die korrekten Hostinger MX-Einträge existieren
    required_mx = [
        {'priority': 5, 'server': 'mx1.hostinger.com', 'ttl': 60},
        {'priority': 10, 'server': 'mx2.hostinger.com', 'ttl': 60}
    ]
    
    has_correct_mx1 = False
    has_correct_mx2 = False
    wrong_ttl = False
    
    for mx in mx_records:
        content = mx['content']
        ttl = mx['ttl']
        
        # Content ist im Format "10 mx1.hostinger.com." oder "5 mx1.hostinger.com."
        if 'mx1.hostinger.com' in content:
            if '5 ' in content and ttl == 60:
                has_correct_mx1 = True
            else:
                wrong_ttl = True
        elif 'mx2.hostinger.com' in content:
            if '10 ' in content and ttl == 60:
                has_correct_mx2 = True
            else:
                wrong_ttl = True
    
    # Wenn alle korrekt sind, nichts tun
    if has_correct_mx1 and has_correct_mx2 and not wrong_ttl:
        print(f"  ✅ Hostinger MX-Einträge sind korrekt")
        return
    
    # Ansonsten: Lösche ALLE @ MX-Einträge und füge die korrekten hinzu
    api_instance = hostinger_api.DNSZoneApi(api_client)
    
    if mx_records:
        print(f"  🔄 Korrigiere Hostinger MX-Einträge...")
        try:
            # Lösche alle @ MX-Einträge
            delete_request = hostinger_api.DNSV1ZoneDestroyRequest(
                filters=[
                    hostinger_api.DNSV1ZoneDestroyRequestFiltersInner(
                        name='@',
                        type='MX'
                    )
                ]
            )
            api_instance.delete_dns_records_v1(domain, delete_request)
            print(f"     🗑️  Alte MX-Einträge gelöscht")
            time.sleep(0.5)
        except ApiException as e:
            print(f"     ⚠️  Fehler beim Löschen: {e}")
    else:
        print(f"  ➕ Füge Hostinger MX-Einträge hinzu...")
    
    # Füge die korrekten Hostinger MX-Einträge hinzu
    try:
        update_request = hostinger_api.DNSV1ZoneUpdateRequest(
            overwrite=True,
            zone=[
                hostinger_api.DNSV1ZoneUpdateRequestZoneInner(
                    name='@',
                    type='MX',
                    ttl=60,
                    records=[
                        hostinger_api.DNSV1ZoneUpdateRequestZoneInnerRecordsInner(
                            content='5 mx1.hostinger.com'
                        ),
                        hostinger_api.DNSV1ZoneUpdateRequestZoneInnerRecordsInner(
                            content='10 mx2.hostinger.com'
                        )
                    ]
                )
            ]
        )
        api_instance.update_dns_records_v1(domain, update_request)
        print(f"     ✅ MX: @ → 5 mx1.hostinger.com (TTL: 60)")
        print(f"     ✅ MX: @ → 10 mx2.hostinger.com (TTL: 60)")
    except ApiException as e:
        print(f"     ❌ Fehler beim Hinzufügen: {e}")


def get_base_domain(domain: str) -> str:
    """Extrahiere die Basis-Domain (ohne Subdomain)
    
    Beispiele:
    - n8n.solarcheck365.de -> solarcheck365.de
    - web.solarcheck365.de -> solarcheck365.de
    - solarcheck365.de -> solarcheck365.de
    """
    parts = domain.split('.')
    
    # Wenn es mehr als 2 Teile hat, ist es eine Subdomain
    if len(parts) > 2:
        # Nimm die letzten 2 Teile (domain.tld)
        return '.'.join(parts[-2:])
    
    # Ansonsten ist es bereits die Basis-Domain
    return domain


def process_domain(api_client, domain: str):
    """Verarbeite eine Domain komplett"""
    print(f"\n{'='*80}")
    print(f"🌐 Verarbeite Domain: {domain}")
    print(f"{'='*80}")
    
    # Für Subdomains: Verwende die Basis-Domain für DNS-Operationen
    base_domain = get_base_domain(domain)
    
    if base_domain != domain:
        print(f"  ℹ️  Subdomain erkannt: DNS-Einträge werden in {base_domain} angelegt")
    
    # Schritt 1: Lösche alte Einträge (in der Basis-Domain)
    delete_old_email_records(api_client, base_domain)
    
    # Schritt 2: Füge neue AWS SES Einträge hinzu
    dkim_tokens = DKIM_TOKENS.get(domain, [])
    
    if not dkim_tokens:
        print(f"  ⚠️  WARNUNG: Keine DKIM-Tokens für {domain} gefunden!")
        print(f"  ℹ️  Bitte DKIM-Tokens von AWS SES abrufen und zu DKIM_TOKENS hinzufügen")
        return
    
    # Prüfe ob mail subdomain benötigt wird
    # Liste der Gutachter-Domains
    gutachter_domains = [
        "assistenzsystem-gutachten.de",
        "automatisiertgutachten.de",
        "digitale-gutachterhilfe.de",
        "gutachtenautomatisieren.de",
        "gutachter-tools.de",
        "gutachterassistenz.de",
        "gutachterassistent.de",
        "gutachtendigital.de",
        "gutachterprozess.de",
        "ki-fachgutachten.de",
        "zeitfuergutachter.de",
        "zeitplus-fuer-gutachter.de"
    ]
    
    mail_from_domain = None
    if domain in gutachter_domains:
        mail_from_domain = "mail.gutachterassistent.de"
    elif domain == "automatenext.ai":
        mail_from_domain = "mail.automatenext.ai"
    else:
        mail_from_domain = None  # Alle anderen Domains nutzen die Standard-MAIL-FROM von automatenext.ai
    
    # Füge AWS SES Einträge hinzu (in der Basis-Domain, aber mit korrekten Namen)
    add_aws_ses_records(api_client, base_domain, domain, dkim_tokens, mail_from_domain)
    
    time.sleep(1)  # Rate limiting zwischen Domains


def main():
    """Hauptfunktion"""
    print("\n" + "="*80)
    print("🚀 AWS SES DNS Setup für Hostinger")
    print("="*80)
    
    # ⚠️ WICHTIG: DKIM-Tokens müssen noch von AWS SES abgerufen werden!
    if not DKIM_TOKENS:
        print("\n❌ FEHLER: DKIM_TOKENS ist leer!")
        print("\nBitte führe zuerst folgenden AWS CLI Befehl aus:")
        print("Oder nutze das AWS SDK, um die DKIM-Tokens für alle Domains abzurufen")
        print("\nDann füge die Tokens in DKIM_TOKENS am Anfang des Skripts ein:")
        print("DKIM_TOKENS = {")
        print('    "domain.de": ["token1", "token2", "token3"],')
        print('    ...')
        print("}")
        return
    
    # API Client initialisieren
    api_client = init_api_client()
    
    # Teste API-Verbindung
    print("\n✅ API-Client initialisiert")
    print(f"📊 {len(ALL_DOMAINS)} Domains werden verarbeitet\n")
    
    # Verarbeite alle Domains
    success_count = 0
    error_count = 0
    
    for domain in ALL_DOMAINS:
        try:
            process_domain(api_client, domain)
            success_count += 1
        except Exception as e:
            print(f"\n❌ Fehler bei {domain}: {e}")
            error_count += 1
    
    # Zusammenfassung
    print("\n" + "="*80)
    print("📊 ZUSAMMENFASSUNG")
    print("="*80)
    print(f"✅ Erfolgreich: {success_count} Domains")
    print(f"❌ Fehler: {error_count} Domains")
    print(f"📝 Gesamt: {len(ALL_DOMAINS)} Domains")
    print("="*80 + "\n")


if __name__ == "__main__":
    main()
