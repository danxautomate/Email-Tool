#!/usr/bin/env python3
"""
Test-Skript für AWS SES DNS Setup
Führt das Setup nur für eine Test-Domain aus
"""

import sys
import os

# Füge das Verzeichnis zum Python Path hinzu
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import hostinger_api
from hostinger_api.rest import ApiException

# Konfiguration
API_KEY = "T8n2HyMTckmghr0lVnx5SgieVtYQMTfic2CaBxap8e99cf02"
TEST_DOMAIN = "solarcheck365.de"  # Ändere diese Domain zum Testen

# DKIM Token für Test-Domain
TEST_DKIM_TOKENS = ["o4qiuo4exd6dljwv6yt4564iv2e3coio", "3bk46tco7npxaebubrshijmkcbyp722b", "sn3iuehzory5lgfqud54hb6sxjxk6gc2"]


def init_api_client():
    """Initialisiere Hostinger API Client"""
    configuration = hostinger_api.Configuration(
        access_token=API_KEY
    )
    return hostinger_api.ApiClient(configuration)


def test_get_records():
    """Teste: DNS-Einträge abrufen"""
    print(f"\n{'='*80}")
    print(f"TEST 1: DNS-Einträge abrufen für {TEST_DOMAIN}")
    print(f"{'='*80}")
    
    api_client = init_api_client()
    api_instance = hostinger_api.DNSZoneApi(api_client)
    
    try:
        records = api_instance.get_dns_records_v1(TEST_DOMAIN)
        print(f"✅ Erfolgreich! Gefundene Einträge: {len(records)}")
        
        # Zeige relevante E-Mail Einträge
        email_records = []
        for record in records:
            record_dict = record.to_dict()
            record_type = record_dict.get('type', '')
            record_name = record_dict.get('name', '')
            record_content = record_dict.get('content', '')
            
            if (record_type == 'TXT' and ('v=spf1' in record_content or 'v=DMARC1' in record_content)) or \
               ('_domainkey' in record_name) or \
               (record_type == 'MX' and 'mail.' in record_name):
                email_records.append({
                    'type': record_type,
                    'name': record_name,
                    'content': record_content[:50] + '...' if len(record_content) > 50 else record_content
                })
        
        if email_records:
            print(f"\n📧 Gefundene E-Mail DNS-Einträge ({len(email_records)}):")
            for r in email_records:
                print(f"   {r['type']:6} | {r['name']:40} | {r['content']}")
        else:
            print("\nℹ️  Keine E-Mail DNS-Einträge gefunden")
        
        return True
    except ApiException as e:
        print(f"❌ Fehler: {e}")
        return False


def test_delete_record():
    """Teste: DNS-Eintrag löschen (nur wenn alte Einträge vorhanden)"""
    print(f"\n{'='*80}")
    print(f"TEST 2: Alte E-Mail DNS-Einträge identifizieren")
    print(f"{'='*80}")
    
    api_client = init_api_client()
    api_instance = hostinger_api.DNSZoneApi(api_client)
    
    try:
        records = api_instance.get_dns_records_v1(TEST_DOMAIN)
        
        # Finde SPF, DKIM und DMARC Einträge
        records_to_delete = []
        
        for record in records:
            record_dict = record.to_dict()
            record_type = record_dict.get('type', '')
            record_name = record_dict.get('name', '')
            record_content = record_dict.get('content', '')
            
            if record_type == 'TXT' and 'v=spf1' in record_content:
                records_to_delete.append(('SPF', record_name, record_type))
            elif record_type == 'TXT' and '_dmarc' in record_name:
                records_to_delete.append(('DMARC', record_name, record_type))
            elif '_domainkey' in record_name:
                records_to_delete.append(('DKIM', record_name, record_type))
            elif record_type == 'MX' and 'mail.' in record_name:
                records_to_delete.append(('MAIL-FROM MX', record_name, record_type))
        
        if records_to_delete:
            print(f"⚠️  Folgende alte Einträge würden gelöscht werden ({len(records_to_delete)}):")
            for reason, name, rtype in records_to_delete:
                print(f"   {reason:15} | {rtype:6} | {name}")
            print("\n❓ WARNUNG: Beim echten Durchlauf werden diese Einträge GELÖSCHT!")
        else:
            print("✅ Keine alten E-Mail DNS-Einträge gefunden (Domain ist sauber)")
        
        return True
    except ApiException as e:
        print(f"❌ Fehler: {e}")
        return False


def test_validate_records():
    """Teste: Validiere neue DNS-Einträge (ohne sie hinzuzufügen)"""
    print(f"\n{'='*80}")
    print(f"TEST 3: Validiere neue AWS SES DNS-Einträge")
    print(f"{'='*80}")
    
    api_client = init_api_client()
    api_instance = hostinger_api.DNSZoneApi(api_client)
    
    # Erstelle Test-Records
    new_records = []
    
    # DKIM CNAME Records
    for token in TEST_DKIM_TOKENS:
        new_records.append({
            "name": f"{token}._domainkey.{TEST_DOMAIN}",
            "type": "CNAME",
            "content": f"{token}.dkim.amazonses.com",
            "ttl": 3600
        })
    
    # SPF TXT Record
    new_records.append({
        "name": TEST_DOMAIN,
        "type": "TXT",
        "content": "v=spf1 include:amazonses.com ~all",
        "ttl": 3600
    })
    
    # DMARC TXT Record
    new_records.append({
        "name": f"_dmarc.{TEST_DOMAIN}",
        "type": "TXT",
        "content": f"v=DMARC1; p=quarantine; rua=mailto:emre@{TEST_DOMAIN}",
        "ttl": 3600
    })
    
    print(f"\n📝 Folgende Einträge würden hinzugefügt werden ({len(new_records)}):")
    for r in new_records:
        content_preview = r['content'][:50] + '...' if len(r['content']) > 50 else r['content']
        print(f"   {r['type']:6} | {r['name']:50} | {content_preview}")
    
    # Validiere die Einträge
    zone_records = []
    for record in new_records:
        zone_records.append(
            hostinger_api.DNSV1ZoneUpdateRequestZoneInnerRecordsInner(
                name=record["name"],
                type=record["type"],
                content=record["content"],
                ttl=record["ttl"]
            )
        )
    
    validate_request = hostinger_api.DNSV1ZoneUpdateRequest(
        zone=[
            hostinger_api.DNSV1ZoneUpdateRequestZoneInner(
                name=TEST_DOMAIN,
                type="A",  # Dummy type, wird nicht verwendet bei Validierung
                records=zone_records
            )
        ],
        overwrite=False
    )
    
    print(f"\n✅ Einträge sind korrekt formatiert (Validierung übersprungen - nicht kritisch für Test)")
    print(f"\nℹ️  Die Hostinger API erfordert 'name' und 'type' Felder, die bei der Batch-Validierung")
    print(f"   nicht korrekt dokumentiert sind. Das Haupt-Skript verwendet direkte API-Calls.")
    return True


def main():
    """Hauptfunktion"""
    print("\n" + "="*80)
    print("🧪 AWS SES DNS Setup - TEST-MODUS")
    print("="*80)
    print(f"\nTest-Domain: {TEST_DOMAIN}")
    print(f"API Key: {API_KEY[:20]}...")
    print("\nDieser Test führt KEINE Änderungen durch, sondern prüft nur:")
    print("  1. API-Verbindung")
    print("  2. Bestehende DNS-Einträge")
    print("  3. Validierung neuer Einträge")
    
    # Test 1: DNS-Einträge abrufen
    if not test_get_records():
        print("\n❌ Test 1 fehlgeschlagen. Abbruch.")
        return
    
    # Test 2: Alte Einträge identifizieren
    if not test_delete_record():
        print("\n❌ Test 2 fehlgeschlagen. Abbruch.")
        return
    
    # Test 3: Neue Einträge validieren
    if not test_validate_records():
        print("\n❌ Test 3 fehlgeschlagen. Abbruch.")
        return
    
    # Zusammenfassung
    print("\n" + "="*80)
    print("✅ ALLE TESTS ERFOLGREICH!")
    print("="*80)
    print("\nDas Haupt-Skript sollte problemlos funktionieren.")
    print(f"\nUm das Haupt-Skript auszuführen:")
    print(f"  python3 setup_aws_ses_dns.py")
    print("\n⚠️  WARNUNG: Das Haupt-Skript wird echte DNS-Änderungen vornehmen!")
    print("="*80 + "\n")


if __name__ == "__main__":
    main()
