#!/usr/bin/env python3
"""
Debug Script - Zeigt alle DNS-Einträge einer Domain
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import hostinger_api
from hostinger_api.rest import ApiException
import json

# Konfiguration
API_KEY = "T8n2HyMTckmghr0lVnx5SgieVtYQMTfic2CaBxap8e99cf02"

def init_api_client():
    configuration = hostinger_api.Configuration(
        access_token=API_KEY
    )
    return hostinger_api.ApiClient(configuration)

def debug_domain(domain):
    """Zeige ALLE DNS-Einträge einer Domain im Detail"""
    print(f"\n{'='*80}")
    print(f"🔍 DEBUG: {domain}")
    print(f"{'='*80}\n")
    
    api_client = init_api_client()
    api_instance = hostinger_api.DNSZoneApi(api_client)
    
    try:
        records = api_instance.get_dns_records_v1(domain)
        
        print(f"📊 Gefundene Einträge: {len(records)}\n")
        
        for i, record in enumerate(records, 1):
            record_dict = record.to_dict()
            
            # Zeige jeden Eintrag im Detail
            print(f"--- Eintrag #{i} ---")
            print(f"Type: {record_dict.get('type', 'N/A')}")
            print(f"Name: {record_dict.get('name', 'N/A')}")
            print(f"Content: {record_dict.get('content', 'N/A')}")
            print(f"TTL: {record_dict.get('ttl', 'N/A')}")
            print(f"Priority: {record_dict.get('priority', 'N/A')}")
            
            # Zeige auch die rohen Daten
            print(f"RAW: {json.dumps(record_dict, indent=2)}")
            print()
            
    except ApiException as e:
        print(f"❌ Fehler: {e}")

if __name__ == "__main__":
    # Teste mit assistenzsystem-gutachten.de
    debug_domain("assistenzsystem-gutachten.de")
