# AWS SES DNS Setup für Hostinger

## 🎯 Was macht dieses Skript?

Dieses Skript automatisiert die DNS-Konfiguration für alle deine Domains bei Hostinger, um AWS SES (Simple Email Service) für den Versand von Kalt-E-Mails zu nutzen.

### Das Skript macht Folgendes:

1. **Löscht alte DNS-Einträge** (SPF, DKIM, DMARC) von jeder Domain
2. **Fügt neue AWS SES DNS-Einträge hinzu**:
   - 3 DKIM CNAME-Einträge pro Domain
   - 1 SPF TXT-Eintrag
   - 1 DMARC TXT-Eintrag
   - MAIL-FROM Domain Konfiguration (MX + SPF) wo benötigt

## 📋 Voraussetzungen

- Python 3.7 oder höher
- Hostinger API Key
- AWS SES bereits konfiguriert (Identitäten erstellt)

## 🚀 Installation

1. Wechsle in das Verzeichnis:
```bash
cd /Users/emre_gueclue/Downloads/api-python-sdk-main
```

2. Installiere die Requirements:
```bash
pip3 install -r requirements.txt
```

Oder falls pip3 nicht verfügbar ist:
```bash
python3 -m pip install -r requirements.txt
```

## ▶️ Ausführung

### Test-Modus (empfohlen für ersten Durchlauf)

Führe das Skript zunächst mit einer einzelnen Test-Domain aus:

```bash
python3 setup_aws_ses_dns.py
```

### Vollständige Ausführung

Wenn der Test erfolgreich war, führe das Skript für alle 54 Domains aus:

```bash
python3 setup_aws_ses_dns.py
```

Das Skript wird:
- ✅ Jeden Schritt protokollieren
- ⏳ Rate Limiting beachten (Pausen zwischen Anfragen)
- 📊 Am Ende eine Zusammenfassung anzeigen

## 📊 Was passiert bei der Ausführung?

Für jede der 54 Domains:

1. **Alte Einträge löschen**:
   - Sucht nach bestehenden SPF, DKIM, DMARC Einträgen
   - Löscht diese sicher

2. **Neue AWS SES Einträge hinzufügen**:
   - 3× DKIM CNAME-Einträge
   - 1× SPF TXT-Eintrag (`v=spf1 include:amazonses.com ~all`)
   - 1× DMARC TXT-Eintrag (`v=DMARC1; p=quarantine; rua=mailto:emre@domain.de`)

3. **MAIL-FROM Domain Konfiguration**:
   - **12 Gutachter-Domains** → nutzen `mail.gutachterassistent.de`
   - **Alle anderen Domains** → nutzen `mail.automatenext.ai`

## 🔧 Konfiguration

### MAIL-FROM Domain Zuordnung

Die Domains sind wie folgt zugeordnet:

**Gutachter-Domains (nutzen `mail.gutachterassistent.de`):**
- assistenzsystem-gutachten.de
- automatisiertgutachten.de
- digitale-gutachterhilfe.de
- gutachtenautomatisieren.de
- gutachter-tools.de
- gutachterassistenz.de
- gutachterassistent.de
- gutachtendigital.de
- gutachterprozess.de
- ki-fachgutachten.de
- zeitfuergutachter.de
- zeitplus-fuer-gutachter.de

**Alle anderen Domains** nutzen `mail.automatenext.ai` (indirekt)

## ⏱️ Dauer

- Pro Domain: ca. 3-5 Sekunden
- Gesamt (54 Domains): ca. 3-5 Minuten

## 📝 Logs

Das Skript zeigt detaillierte Logs:

```
================================================================================
🌐 Verarbeite Domain: example.de
================================================================================

🔍 Prüfe example.de auf alte E-Mail DNS-Einträge...
  🗑️  Lösche 5 alte E-Mail DNS-Einträge:
     - SPF: example.de (TXT)
     - DKIM: token1._domainkey.example.de (CNAME)
     - DKIM: token2._domainkey.example.de (CNAME)
     - DKIM: token3._domainkey.example.de (CNAME)
     - DMARC: _dmarc.example.de (TXT)
  ✅ Alte Einträge gelöscht

📝 Füge AWS SES DNS-Einträge für example.de hinzu...
  ✅ 5 DNS-Einträge hinzugefügt:
     - CNAME: newtoken1._domainkey.example.de
     - CNAME: newtoken2._domainkey.example.de
     - CNAME: newtoken3._domainkey.example.de
     - TXT: example.de
     - TXT: _dmarc.example.de
```

## ✅ Nach der Ausführung

### 1. DNS-Propagation prüfen

DNS-Änderungen können 5 Minuten bis 48 Stunden dauern. Prüfe mit:

```bash
# DKIM prüfen
dig token._domainkey.example.de CNAME

# SPF prüfen  
dig example.de TXT

# DMARC prüfen
dig _dmarc.example.de TXT
```

### 2. AWS SES Verifikation prüfen

Gehe zu AWS SES Console → Verified Identities und prüfe den Status jeder Domain.

### 3. Test-E-Mail senden

Sende eine Test-E-Mail über AWS SES, um sicherzustellen, dass alles funktioniert.

## ⚠️ Wichtige Hinweise

1. **Backup**: Das Skript löscht alte DNS-Einträge. Erstelle vorher ein Backup deiner DNS-Konfiguration in Hostinger!

2. **Rate Limiting**: Das Skript beachtet automatisch Rate Limits der Hostinger API

3. **Fehlerbehandlung**: Bei Fehlern zeigt das Skript Details an und fährt mit der nächsten Domain fort

4. **MAIL-FROM Domains**: Die Subdomains `mail.automatenext.ai` und `mail.gutachterassistent.de` müssen NICHT separat als DNS-Zonen in Hostinger angelegt werden - sie werden über die Haupt-Domains verifiziert

## 🐛 Fehlerbehebung

### "Module 'hostinger_api' not found"
```bash
pip3 install -r requirements.txt
```

### "API Authentication failed"
- Prüfe, ob der API Key korrekt ist
- Stelle sicher, dass der Key aktiv ist

### "Domain not found"
- Prüfe, ob die Domain in deinem Hostinger Account existiert
- Manche Subdomains (wie info.solarcheck365.de) benötigen eventuell separate DNS-Zonen

### "Rate limit exceeded"
- Das Skript wartet automatisch zwischen Anfragen
- Falls Fehler auftritt, warte 5 Minuten und führe das Skript erneut aus

## 📞 Support

Bei Problemen:
1. Prüfe die Logs auf Fehlerdetails
2. Verifiziere, dass alle Domains in Hostinger existieren
3. Prüfe AWS SES Console für Domain-Status

## 🎉 Erfolg!

Nach erfolgreicher Ausführung sind alle 54 Domains für AWS SES konfiguriert und bereit für den Versand von Kalt-E-Mails!
